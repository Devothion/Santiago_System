<div>
    <div class="card">
        <div class="card-header">
            <div class="d-flex w-full justify-content-around">
                
            </div>
            <div class="d-flex">
                <a href="<?php echo e(route('admin.solicitudes.create')); ?>" class="btn btn-block btn-danger w-25 m-2"><i class="fa-solid fa-hand-holding-dollar mr-1"></i>Nueva Solicitud</a>
                <button class="btn btn-block btn-success w-25 m-2" wire:click='export'><i class="fa fa-file-excel mr-1"></i>Descargar Patron</button>
                <button class="btn btn-block btn-primary w-25 m-2" wire:click='export1'><i class="fa-solid fa-circle-plus mr-1"></i>Asignar otros conceptos</button>
                <a href="#" class="btn btn-block btn-dark w-25 m-2"><i class="fa-solid fa-file-pen mr-1"></i>Actualizar Status</a>
            </div>
            <div class="d-flex">
                <input type="text" wire:model.live="search" class="form-control" placeholder="Buscar por DNI o Apellidos">
            </div>
        </div>
        <div class="card-body">

            <!-- __BLOCK__ --><?php if($prestamos->count()): ?>
                <table id="" class="table table-bordered table-striped">
                    <thead class="text-center">
                        <tr>
                            <th style="cursor: pointer;" wire:click="order('id')">ID 
                            <!-- Sort -->
                            <!-- __BLOCK__ --><?php if($sort == 'id'): ?>
                                <!-- __BLOCK__ --><?php if($direction == 'asc'): ?>
                                    <i class="fa-solid fa-arrow-down-1-9 float-right mt-1"></i>
                                <?php else: ?>
                                    <i class="fa-solid fa-arrow-down-9-1 float-right mt-1"></i>
                                <?php endif; ?> <!-- __ENDBLOCK__ -->
                            <?php else: ?>
                                <i class="fa-solid fa-sort float-right mt-1"></i>
                            <?php endif; ?> <!-- __ENDBLOCK__ --></th>
                            <th style="cursor: pointer;" wire:click="order('nombre_cliente')">Nombres
                            <!-- Sort -->
                            <!-- __BLOCK__ --><?php if($sort == 'nombre_cliente'): ?>
                                <!-- __BLOCK__ --><?php if($direction == 'asc'): ?>
                                    <i class="fa-solid fa-arrow-down-a-z float-right mt-1"></i>
                                <?php else: ?>
                                    <i class="fa-solid fa-arrow-down-z-a float-right mt-1"></i>
                                <?php endif; ?> <!-- __ENDBLOCK__ -->
                            <?php else: ?>
                                <i class="fa-solid fa-sort float-right mt-1"></i>
                            <?php endif; ?> <!-- __ENDBLOCK__ --></th>
                            <th style="cursor: pointer;">DNI
                            <!-- Sort -->
                            <!-- __BLOCK__ --><?php if($sort == 'nombre_cliente'): ?>
                                <!-- __BLOCK__ --><?php if($direction == 'asc'): ?>
                                    <i class="fa-solid fa-arrow-down-1-9 float-right mt-1"></i>
                                <?php else: ?>
                                    <i class="fa-solid fa-arrow-down-9-1 float-right mt-1"></i>
                                <?php endif; ?> <!-- __ENDBLOCK__ -->
                            <?php else: ?>
                                <i class="fa-solid fa-sort float-right mt-1"></i>
                            <?php endif; ?> <!-- __ENDBLOCK__ --></th>
                            <th style="cursor: pointer;" wire:click="order('mon_sol')">Monto
                            <!-- Sort -->
                            <!-- __BLOCK__ --><?php if($sort == 'mon_sol'): ?>
                                <!-- __BLOCK__ --><?php if($direction == 'asc'): ?>
                                    <i class="fa-solid fa-arrow-down-1-9 float-right mt-1"></i>
                                <?php else: ?>
                                    <i class="fa-solid fa-arrow-down-9-1 float-right mt-1"></i>
                                <?php endif; ?> <!-- __ENDBLOCK__ -->
                            <?php else: ?>
                                <i class="fa-solid fa-sort float-right mt-1"></i>
                            <?php endif; ?> <!-- __ENDBLOCK__ --></th>
                            <th>Estado</th>
                            <th style="cursor: pointer;" wire:click="order('created_at')">Fecha de Creacion
                            <!-- Sort -->
                            <!-- __BLOCK__ --><?php if($sort == 'created_at'): ?>
                                <!-- __BLOCK__ --><?php if($direction == 'asc'): ?>
                                    <i class="fa-solid fa-arrow-down-1-9 float-right mt-1"></i>
                                <?php else: ?>
                                    <i class="fa-solid fa-arrow-down-9-1 float-right mt-1"></i>
                                <?php endif; ?> <!-- __ENDBLOCK__ -->
                            <?php else: ?>
                                <i class="fa-solid fa-sort float-right mt-1"></i>
                            <?php endif; ?> <!-- __ENDBLOCK__ --></th>
                            <th>Opciones</th>
                        </tr>
                    </thead>
                    <tbody class="text-center">
                        <!-- __BLOCK__ --><?php $__currentLoopData = $prestamos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prestamo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($prestamo->id); ?></td>
                            <td><?php echo e($prestamo->nombre_cliente); ?></td>
                            <td><?php echo e($prestamo->cliente->documento); ?></td>
                            <td>S/. <?php echo e($prestamo->mon_sol); ?></td>
                            <td>
                                <!-- __BLOCK__ --><?php if($prestamo->estado == 'Aprobado'): ?>
                                    <span class="badge badge-success">Aprobado</span>
                                <?php elseif($prestamo->estado == 'En Analisis'): ?>
                                    <span class="badge badge-info">En Analisis</span>
                                <?php elseif($prestamo->estado == 'En Espera'): ?>
                                    <span class="badge badge-warning">En Espera</span>
                                <?php else: ?>
                                    <span class="badge badge-danger">Finalizado</span>
                                <?php endif; ?> <!-- __ENDBLOCK__ -->
                                    
                            </td>
                            <td><?php echo e($prestamo->fech_ate); ?></td>
                            <td>
                                <div class="btn-group">
                                    <button class="btn btn-secondary btn-sm dropdown-toggle" type="button" data-toggle="dropdown" aria-expanded="false">
                                        Acciones
                                    </button>
                                    <div class="dropdown-menu">
                                        <a href="<?php echo e(route('admin.prestamos.show', ['prestamo' => $prestamo->id ])); ?>" class="dropdown-item"><i class="far fa-eye mr-1"></i>Estado de Cuenta</a>
                                        <a href="#" class="dropdown-item"><i class="fas fa-file-pdf mr-1"></i>Control de Pagos</a>
                                        <a href="#" class="dropdown-item"><i class="fas fa-file-pdf mr-1"></i>Cronograma</a>
                                        <a href="<?php echo e(route('admin.registrarpago.edit', ['registrar_pago' => $prestamo->id])); ?>" class="dropdown-item"><i class="fas fa-dollar-sign mr-1"></i>Registrar Pagos</a>
                                        <a href="<?php echo e(route('admin.registrarpagolibre.edit', ['registrar_pago_libre' => $prestamo->id])); ?>" class="dropdown-item"><i class="fas fa-dollar-sign mr-1"></i>Registrar Pago Libre</a>
                                        <a href="<?php echo e(route('admin.gestioncobranza.create', ['solicitud_id' => $prestamo->id])); ?>" class="dropdown-item"><i class="fas fa-chart-simple mr-1"></i>Gestion Cobranza</a> 
                                    </div>
                                </div>
                            </td>
                        </tr>
                        
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!-- __ENDBLOCK__ -->
                    </tbody>
                </table>
                <div class="float-right mt-3">
                    <?php echo e($prestamos->links()); ?>

                </div>
            <?php else: ?>
                <div class="text-center">
                    <p class="font-weight-bold text-muted">No hemos encontrado algun registro coincidente</p>
                </div>
            <?php endif; ?> <!-- __ENDBLOCK__ -->
            
        </div>
    </div>  
</div>
<?php /**PATH C:\xampp\htdocs\Santiago-System\resources\views/livewire/prestamos/show-prestamos.blade.php ENDPATH**/ ?>