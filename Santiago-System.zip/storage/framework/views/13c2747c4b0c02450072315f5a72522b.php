<div>
    <div class="card card-secondary">
        <div class="card-header">
            <div class="card-title">
                Pago de Cuotas
            </div>
        </div>
        <div class="card-body">
            <table id="" class="table table-sm">
                <thead>
                    <tr>
                        <th class="d-none">ID de Cuota</th>
                        <th>N° Cuota</th>
                        <th>Fecha de Vencimiento</th>
                        <th>Interes</th>
                        <th>Cuota</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="d-none">
                                <input type="text" class="form-control" value="<?php echo e($row['column1']); ?>" readonly>
                            </td>
                            <td>
                                <input type="text" class="form-control" value="<?php echo e($row['column5']); ?>" readonly>
                            </td>
                            <td>
                                <input type="text" class="form-control" value="<?php echo e(\Carbon\Carbon::parse($row['column3'])->format('d-m-Y')); ?>" readonly>
                            </td>
                            <td>
                                <input type="text" class="form-control" value="<?php echo e("S/ ".$row['column2']); ?>" readonly>
                            </td>
                            <td>
                                <input type="text" class="form-control" value="<?php echo e("S/ ".$row['column4']); ?>" readonly>
                            </td>
                            <!--[if BLOCK]><![endif]--><?php if($row['column1'] != $baseRowId && $isLastRow && $loop->last): ?>
                                <td><button wire:click.prevent="eliminarCuota(<?php echo e($row['column1']); ?>)" class="btn btn-danger"><i class="fa-solid fa-xmark"></i></button></td>
                            <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
                </tbody>
                <tfoot>
                    <tr>
                        <td></td>
                        <td></td>
                        <td class="text-primary font-weight-bold align-middle pl-3" id="subTotal">S/  <?php echo e($totalInteres); ?></td>
                        <td class="text-primary font-weight-bold align-middle pl-3" id="subTotal">S/ <?php echo e($subtotal); ?></td>
                    </tr>
                    
                </tfoot>
            </table>
        </div>
        <div class="card-footer">
            <div class="row">
                <div class="col-1">
                    <input type="number" class="form-control" value="1">
                </div>
                <div class="col-2">
                    <button wire:click.prevent='agregarCuota' class="btn btn-success">Agregar Cuotas</button>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\Santiago-System\resources\views/livewire/prestamos/registrar-pago/show-tabla-cuotas.blade.php ENDPATH**/ ?>