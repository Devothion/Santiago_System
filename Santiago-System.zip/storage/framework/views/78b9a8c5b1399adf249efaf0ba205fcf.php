<a href="/">
    
    <img class="w-20 h-20" src="<?php echo e(asset('vendor/adminlte/dist/img/SantiagoLogoDark.png')); ?>" alt="admin">
</a>
<?php /**PATH C:\xampp\htdocs\Santiago-System\resources\views/components/authentication-card-logo.blade.php ENDPATH**/ ?>