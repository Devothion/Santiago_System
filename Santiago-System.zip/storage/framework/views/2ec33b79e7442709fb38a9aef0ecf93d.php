<div class="col-4">
    <div class="form-group">
        <label for="abono">Abono</label>
        <input type="number" class="form-control" name="abono" id="abono" value="<?php echo e($subtotal); ?>" readonly>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\Santiago-System\resources\views/livewire/prestamos/registrar-pago/show-sub-total.blade.php ENDPATH**/ ?>