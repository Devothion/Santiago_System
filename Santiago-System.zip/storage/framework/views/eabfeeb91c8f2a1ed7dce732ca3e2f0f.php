

<?php $__env->startSection('title', 'Nuevo Cliente'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1 class="m-0 text-dark">Editar cliente</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-------------------------------------------------------->
    <!-- NO OLVIDAR QUE TODO ESTO TIENE QUE ESTAR DENTRO DE -->
    <!-- DE UNA ETIQUETA FORM PARA QUE SE MANEJEN LOS DATOS -->
    <!-------------------------------------------------------->
    <form action="<?php echo e(route('admin.clientes.update', ['cliente' => $cliente->id])); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="card">
            <div class="card-body">
                <div class="row">
                    <div class="col-12 mb-3">
                        <div class="form-group">
                            <div class="text-center">
                                <img src="<?php echo e(asset('storage/'. $cliente->imagen)); ?>" class="rounded mx-auto d-block" id="img" alt="userPhoto" style="height: 150px;">
                            </div>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="d-flex justify-content-center mb-4">
                            <div class="form-group mr-1">
                                <div class="adjuntar-foto">
                                    <label for="file" class="btn btn-info"><i class="fa fa-upload mr-1"></i>Seleccionar foto</label>
                                    <input id="file" type="file" name="file" style="display: none;" requerid>
                                </div>
                            </div>
                            <div class="form-group ml-1">
                                <a data-toggle="modal" data-target="#verFoto-modal" class="btn btn-secondary"><i class="fa-solid fa-magnifying-glass-plus mr-1"></i><strong>Visualizar foto</strong></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="form-group">
                            <label for="sucursal">Sucursal</label>
                            <select class="form-control" id="sucursal" name="sucursal">
                                <option value=""<?php echo e(old('sucursal', $cliente->sucursal) == '' ? ' selected' : ''); ?>>Selecciona</option>
                                <?php $__currentLoopData = $sucursales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sucursal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($sucursal->id); ?>"<?php echo e(old('sucursal', $cliente->sucursal) == $sucursal->id ? ' selected' : ''); ?>><?php echo e($sucursal->sucursal); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                            
                            </select>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="form-group">
                            <label for="jcc">JCC</label>
                            <select class="form-control" id="jcc" name="jcc">
                                <option value=""<?php echo e(old('jcc', $cliente->jcc) == '' ? ' selected' : ''); ?>>Selecciona</option>
                                <?php $__currentLoopData = $jccs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jcc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($jcc->id); ?>"<?php echo e(old('sucursal', $cliente->jcc) == $jcc->id ? ' selected' : ''); ?>><?php echo e($jcc->nombres); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="form-group">
                            <label for="asesorCredito">Asesor de Credito</label>
                            <select class="form-control" id="asesorCredito" name="asesorCredito">
                                <option value=""<?php echo e(old('asesorCredito', $cliente->asesor) == '' ? ' selected' : ''); ?>>Selecciona</option>
                                <?php $__currentLoopData = $asesores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asesor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($asesor->id); ?>"<?php echo e(old('sucursal', $cliente->asesor) == $asesor->id ? ' selected' : ''); ?>><?php echo e($asesor->nombres); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="form-group">
                            <label for="nDocumento">Numero de documento</label>
                            <input type="number" class="form-control" name="nDocumento" id="nDocumento" value="<?php echo e($cliente->documento); ?>">
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="form-group">
                            <label for="nombres">Nombres</label>
                            <input type="text" class="form-control" name="nombres" id="nombres" value="<?php echo e($cliente->nombres); ?>">
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="form-group">
                            <label for="aPaterno">Apellido Paterno</label>
                            <input type="text" class="form-control" name="aPaterno" id="aPaterno" value="<?php echo e($cliente->ape_pat); ?>">
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="form-group">
                            <label for="aMaterno">Apellido Materno</label>
                            <input type="text" class="form-control" name="aMaterno" id="aMaterno" value="<?php echo e($cliente->ape_mat); ?>">
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="form-group">
                            <label for="telefono">Telefono</label>
                            <input type="number" class="form-control" name="telefono" id="telefono" value="<?php echo e($cliente->telefono); ?>">
                        </div>
                    </div>
                    <div class="col-3">
                        <div class="form-group">
                            <label for="departamento">Departamento</label>
                            <select class="form-control" id="departamento" name="departamento">
                                <option value=""<?php echo e(old('sucursal', $cliente->departamento) == '' ? ' selected' : ''); ?>>Selecciona</option>
                                <?php $__currentLoopData = $departamentos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $departamento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($departamento->id); ?>"<?php echo e(old('sucursal', $cliente->departamento) == $departamento->id ? ' selected' : ''); ?>><?php echo e($departamento->departamento); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-3">
                        <div class="form-group">
                            <label for="provincia">Provincia</label>
                            <select class="form-control" id="provincia" name="provincia">
                                <option value=""<?php echo e(old('sucursal', $cliente->provincia) == '' ? ' selected' : ''); ?>>Selecciona</option>
                                <?php $__currentLoopData = $provincias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $provincia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($provincia->id); ?>"<?php echo e(old('sucursal', $cliente->provincia) == $provincia->id ? ' selected' : ''); ?>><?php echo e($provincia->provincia); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-2">
                        <div class="form-group">
                            <label for="distrito">Distrito</label>
                            <select class="form-control" id="distrito" name="distrito">
                                <option value=""<?php echo e(old('sucursal', $cliente->distrito) == '' ? ' selected' : ''); ?>>Selecciona</option>
                                <?php $__currentLoopData = $distritos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $distrito): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($distrito->id); ?>"<?php echo e(old('sucursal', $cliente->distrito) == $distrito->id ? ' selected' : ''); ?>><?php echo e($distrito->distrito); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-2">
                        <div class="form-group">
                            <label for="zona">Zona</label>
                            <select class="form-control" id="zona" name="zona">
                                <option value=""<?php echo e(old('sucursal', $cliente->zona) == '' ? ' selected' : ''); ?>>Selecciona</option>
                                <?php $__currentLoopData = $zonas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $zona): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($zona->id); ?>"<?php echo e(old('sucursal', $cliente->zona) == $zona->id ? ' selected' : ''); ?>><?php echo e($zona->zona); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-2">
                        <div class="form-group">
                            <label for="tZona">Tipo de Zona</label>
                            <div class="input-group mb-3">
                                <select class="custom-select" id="tZona" name="tZona">
                                    <option value=""<?php echo e(old('sucursal', $cliente->zona) == '' ? ' selected' : ''); ?>>Selecciona</option>
                                    <?php $__currentLoopData = $zonas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $zona): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($zona->id); ?>"<?php echo e(old('sucursal', $cliente->zona) == $zona->id ? ' selected' : ''); ?>><?php echo e($zona->tipo); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <div class="input-group-append">
                                    <a data-toggle="modal" data-target="#agregarZona-modal" class="btn btn-outline-info"><i class="fa-solid fa-circle-plus"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="form-group">
                            <label for="nLotes">Numero de lote</label>
                            <input type="text" class="form-control" name="nLotes" id="nLotes" value="<?php echo e($cliente->nlote); ?>">
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="form-group">
                            <label for="direcDomicilio">Direccion de domicilio</label>
                            <input type="text" class="form-control" name="direcDomicilio" id="direcDomicilio" value="<?php echo e($cliente->direccion); ?>">
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="form-group">
                            <label for="referDomiciliaria">Referencia domiciliaria</label>
                            <input type="text" class="form-control" name="referDomiciliaria" id="referDomiciliaria" value="<?php echo e($cliente->referencia); ?>">
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="form-group">
                            <label for="tCuenta">Tipo de Cuenta</label>
                            <select class="form-control" id="tCuenta" name="tCuenta">
                                <option value=""<?php echo e(old('sucursal', $cliente->tipoCuenta) == '' ? ' selected' : ''); ?>>Selecciona</option>
                                <?php $__currentLoopData = $tipoCuentas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipoCuenta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($tipoCuenta->id); ?>"<?php echo e(old('sucursal', $cliente->tipoCuenta) == $tipoCuenta->id ? ' selected' : ''); ?>><?php echo e($tipoCuenta->tipo); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="form-group">
                            <label for="aval">Aval</label>
                            <select class="form-control" id="aval" name="aval">
                                <?php if($cliente->aval == '0'): ?>
                                    <option value="0" selected>No</option>
                                    <option value="1">Si</option>
                                <?php else: ?>
                                    <option value="0">No</option>
                                    <option value="1" selected>Si</option>
                                <?php endif; ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-12 mt-2" id="finanzas-section" hidden>
                        <h3 class="text-secondary"><strong>FINANZAS</strong></h3>
                        <div class="row">
                            <div class="col-6">
                                <div class="form-group">
                                    <label for="entidadFinanciera">Entidad Financiera</label>
                                    <select class="form-control" id="entidadFinanciera" name="entidadFinanciera">
                                        <option value=""<?php echo e(old('sucursal', $cliente->entidad) == '' ? ' selected' : ''); ?>>Selecciona</option>
                                        <?php $__currentLoopData = $entBancarias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entBancaria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($entBancaria->id); ?>"<?php echo e(old('sucursal', $cliente->entidad) == $entBancaria->id ? ' selected' : ''); ?>><?php echo e($entBancaria->banco); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="form-group">
                                    <label for="f_nCuenta">Numero de cuenta</label>
                                    <input type="number" class="form-control" name="f_nCuenta" id="f_nCuenta" value="<?php echo e($cliente->cuentafi); ?>">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 mt-2" id="cuenta-terceros-section" hidden>
                        <h3 class="text-secondary"><strong>CUENTA TERCEROS</strong></h3>
                        <div class="row">
                            <div class="col-6">
                                <div class="form-group">
                                    <label for="ct_eFinanciera">Entidad Financiera</label>
                                    <select class="form-control" id="ct_eFinanciera" name="ct_eFinanciera">
                                        <option value=""<?php echo e(old('sucursal', $cliente->entidadter) == '' ? ' selected' : ''); ?>>Selecciona</option>
                                        <?php $__currentLoopData = $entBancarias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entBancaria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($entBancaria->id); ?>"<?php echo e(old('sucursal', $cliente->entidadter) == $entBancaria->id ? ' selected' : ''); ?>><?php echo e($entBancaria->banco); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="form-group">
                                    <label for="ct_nCuenta">Numero de cuenta</label>
                                    <input type="number" class="form-control" name="ct_nCuenta" id="ct_nCuenta" value="<?php echo e($cliente->cuentater); ?>">
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="form-group">
                                    <label for="ct_Titular">Titular</label>
                                    <input type="text" class="form-control" name="ct_Titular" id="ct_Titular" value="<?php echo e($cliente->titularter); ?>">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 mt-2" id="aval-section" hidden>
                        <h3 class="text-secondary"><strong>AVAL</strong></h3>
                        <div class="row">
                            <div class="col-4">
                                <div class="form-group">
                                    <label for="av_nDocumento">Numero de documento</label>
                                    <input type="number" class="form-control" name="av_nDocumento" id="av_nDocumento" value="<?php echo e($cliente->documentoav); ?>">
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="form-group">
                                    <label for="av_nombres">Nombres</label>
                                    <input type="text" class="form-control" name="av_nombres" id="av_nombres" value="<?php echo e($cliente->nombresav); ?>">
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="form-group">
                                    <label for="av_aPaterno">Apellido Paterno</label>
                                    <input type="text" class="form-control" name="av_aPaterno" id="av_aPaterno" value="<?php echo e($cliente->ape_patav); ?>">
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="form-group">
                                    <label for="av_aMaterno">Apellido Materno</label>
                                    <input type="text" class="form-control" name="av_aMaterno" id="av_aMaterno" value="<?php echo e($cliente->ape_matav); ?>">
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="form-group">
                                    <label for="av_direcDomicilio">Direccion de domicilio</label>
                                    <input type="text" class="form-control" name="av_direcDomicilio" id="av_direcDomicilio" value="<?php echo e($cliente->direccionav); ?>">
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="form-group">
                                    <label for="av_telefono">Telefono</label>
                                    <input type="number" class="form-control" name="av_telefono" id="av_telefono" value="<?php echo e($cliente->celularav); ?>">
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="form-group">
                                    <label for="av_observaciones">Observaciones</label>
                                    <textarea class="form-control" id="av_observaciones" name="av_observaciones" rows="3"><?php echo e($cliente->observ); ?></textarea>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="d-flex justify-content-between mb-4">
                            <a href="<?php echo e(route('admin.clientes.index')); ?>" class="btn btn-lg btn-dark"><i class="fa-solid fa-right-from-bracket mr-1"></i>Cancelar</a>
                            <button type="submit" class="btn btn-lg btn-success"><i class="fa-solid fa-floppy-disk mr-1"></i>Guardar</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </form>
    <div id="verFoto-modal" class="modal fade" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Previsualizar foto</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="text-center">
                        <img src="<?php echo e(asset('storage/'. $cliente->imagen)); ?>" class="rounded mx-auto d-block" id="view-img" alt="userPhoto" style="height: 400px;">
                    </div>
                </div>
                <div class="modal-footer justify-content-center">
                    <button type="button" class="btn btn-success" data-dismiss="modal">Aceptar</button>
                </div>
            </div>
        </div>
    </div>
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('clientes.zona.create-zona');

$__html = app('livewire')->mount($__name, $__params, 'rstW2n1', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

    <script>
        // TODAVIA FALTAN LAS FUNCIONES PARA PREVISUALIZAR LAS FOTOS //
        $('#tCuenta').change(function() {
            var x = document.getElementById('cuenta-terceros-section')
            var y = document.getElementById('finanzas-section')
            let estado = $('#tCuenta').val();
            console.log('Estas seleccionando: '+estado);
            switch (estado) {
                case '1':
                    x.setAttribute('hidden', true);
                    y.removeAttribute('hidden');
                    break
                case '2':
                    x.removeAttribute('hidden');
                    y.setAttribute('hidden', true);
                    break;
                default:
                    x.setAttribute('hidden', true);
                    y.setAttribute('hidden', true);
                    break;
            }
        });
        $('#aval').change(function() {
            var z = document.getElementById('aval-section');
            let estado = $('#aval').val();
            if (estado == 1) {
                z.removeAttribute('hidden');
            } else {
                z.setAttribute('hidden', true);
            }
        });

        const departamento = document.getElementById('departamento')
        const provincia = document.getElementById('provincia')
        const zona = document.getElementById('zona')
        const tZona = document.getElementById('tZona')

        departamento.addEventListener('change', async (e)=> {
            if (e.target.value == '') {
                provincia.innerHTML = `<option value=''>Selecciona</option>`
                distrito.innerHTML = `<option value=''>Selecciona</option>`
                zona.innerHTML = `<option value=''>Selecciona</option>`
                tZona.innerHTML = `<option value=''>Selecciona</option>`
            } else {
                const response = await fetch(`/api/departamento/${e.target.value}/provincias`)
                const data = await response.json();
                let options = '';
                data.forEach(element => {
                    options = options + `<option value='${element.id}'>${element.provincia}</option>`
                })
                provincia.innerHTML = options
                provincia.addEventListener('change', async (e)=> {
                    const response = await fetch(`/api/provincia/${e.target.value}/distritos`)
                    const data = await response.json();
                    let options = '';
                    data.forEach(element => {
                        options = options + `<option value='${element.id}'>${element.distrito}</option>`
                    })
                    distrito.innerHTML = options
                    
                    distrito.addEventListener('change', async (e)=> {
                        const response = await fetch(`/api/distrito/${e.target.value}/zonas`)
                        const data = await response.json();
                        let options_z = '';
                        let options_tz = '';
                        data.forEach(element_z => {
                            options_z = options_z + `<option value='${element_z.id}'>${element_z.zona}</option>`
                        })
                        data.forEach(element_tz => {
                            options_tz = options_tz + `<option value='${element_tz.id}'>${element_tz.tipo}</option>`
                        })
                        zona.innerHTML = options_z
                        tZona.innerHTML = options_tz
                    })

                    // Dispara el evento change para la distrito
                    var event_d = new Event('change');
                    distrito.dispatchEvent(event_d);

                })

                // Dispara el evento change para la provincia
                var event_p = new Event('change');
                provincia.dispatchEvent(event_p);
    
                
            }
        })

        const defaultFile = 'https://th.bing.com/th/id/OIP.SZEx8juvNTfQweNxIMGUxgHaHa?pid=ImgDet&rs=1';

        const file = document.getElementById('file');
        const img = document.getElementById('img');
        const viewimg = document.getElementById('view-img');
        file.addEventListener( 'change', e => {
        if( e.target.files[0] ){
            const reader = new FileReader( );
            reader.onload = function( e ){
            img.src = e.target.result;
            viewimg.src = e.target.result;
            }
            reader.readAsDataURL(e.target.files[0])
        }else{
            img.src = defaultFile;
            viewimg.src = defaultFile;
        }
        });


        // Escucha el evento 'change' del input en el formulario de clientes
        document.getElementById('distrito').addEventListener('change', function() {
            // Obtiene el valor del input
            var valorInptuDistrito = this.value;
            var nombreInputDitrito = this.options[this.selectedIndex].text;
            // Asigna el valor al input en el formulario de crear zonas
            document.getElementById('distritoZona_id').value = valorInptuDistrito;
            document.getElementById('distritoZona').value = nombreInputDitrito;
        });
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Santiago-System\resources\views/admin/clientes/edit.blade.php ENDPATH**/ ?>