<div>
    <div class="card">
        <div class="card-header">
            <div class="d-flex w-full justify-content-around">
                <div class="row " style="margin-top: 20px;margin-bottom: 20px;margin-left: 10px;">
                    <div style="display: flex;padding: 12px;width: 150px;background-color: #5cb85c;border-radius: 10px;height: 50px;color: black;justify-content: center;margin-right: 10px;text-transform: uppercase;  padding-top: 17px !important;"><p style="font-size: 10pt;">Aprobado: </p> <p style="margin-left: 5px;font-weight: 600;font-size: 16pt;margin-top: -9px;"><?php echo e($cant_aprobado); ?></p></div>
                    <div style="display: flex;padding: 12px;width: 150px;background-color: #5bc0de;border-radius: 10px;height: 50px;color: black;justify-content: center;margin-right: 10px;text-transform: uppercase;  padding-top: 17px !important;"><p style="font-size: 10pt;">En Analisis:</p> <p style="margin-left: 5px;font-weight: 600;font-size: 16pt;margin-top: -9px;"><?php echo e($cant_analisis); ?></p></div>
                    <div style="display: flex;padding: 12px;width: 150px;background-color: #f0ad4e;border-radius: 10px;height: 50px;color: black;justify-content: center;margin-right: 10px;text-transform: uppercase;  padding-top: 17px !important;"><p style="font-size: 10pt;">En Espera: </p> <p style="margin-left: 5px;font-weight: 600;font-size: 16pt;margin-top: -9px;"><?php echo e($cant_espera); ?></p></div>
                    <div style="display: flex;padding: 12px;width: 150px;background-color: #d9534f;border-radius: 10px;height: 50px;color: black;justify-content: center;margin-right: 10px;text-transform: uppercase;  padding-top: 17px !important;"><p style="font-size: 10pt;">Finalizado: </p> <p style="margin-left: 5px;font-weight: 600;font-size: 16pt;margin-top: -9px;"><?php echo e($cant_finalizado); ?></p></div>
                </div>
            </div>
            <div class="d-flex justify-content-center">
                <a href="<?php echo e(route('admin.solicitudes.create')); ?>" class="btn btn-block btn-danger w-25 m-2"><i class="fa-solid fa-hand-holding-dollar mr-1"></i>Nueva Solicitud</a>
                <button class="btn btn-block btn-success w-25 m-2" wire:click='export'><i class="fa fa-file-excel mr-1"></i>Descargar Patron</button>
            </div>
            <div class="d-flex">
                <input type="text" wire:model.live="search" class="form-control" placeholder="Buscar por DNI, Apellidos o Estado">
            </div>
        </div>
        <div class="card-body">

            <!-- __BLOCK__ --><?php if($solicitudes->count()): ?>
                <table id="" class="table table-bordered table-striped">
                    <thead class="text-center">
                        <tr>
                            <th style="cursor: pointer;" wire:click="order('id')">ID 
                            <!-- Sort -->
                            <!-- __BLOCK__ --><?php if($sort == 'id'): ?>
                                <!-- __BLOCK__ --><?php if($direction == 'asc'): ?>
                                    <i class="fa-solid fa-arrow-down-1-9 float-right mt-1"></i>
                                <?php else: ?>
                                    <i class="fa-solid fa-arrow-down-9-1 float-right mt-1"></i>
                                <?php endif; ?> <!-- __ENDBLOCK__ -->
                            <?php else: ?>
                                <i class="fa-solid fa-sort float-right mt-1"></i>
                            <?php endif; ?> <!-- __ENDBLOCK__ --></th>
                            <th style="cursor: pointer;" wire:click="order('cliente')">Nombres
                            <!-- Sort -->
                            <!-- __BLOCK__ --><?php if($sort == 'cliente'): ?>
                                <!-- __BLOCK__ --><?php if($direction == 'asc'): ?>
                                    <i class="fa-solid fa-arrow-down-a-z float-right mt-1"></i>
                                <?php else: ?>
                                    <i class="fa-solid fa-arrow-down-z-a float-right mt-1"></i>
                                <?php endif; ?> <!-- __ENDBLOCK__ -->
                            <?php else: ?>
                                <i class="fa-solid fa-sort float-right mt-1"></i>
                            <?php endif; ?> <!-- __ENDBLOCK__ --></th>
                            <th style="cursor: pointer;" wire:click="order('mon_sol')">Monto
                            <!-- Sort -->
                            <!-- __BLOCK__ --><?php if($sort == 'mon_sol'): ?>
                                <!-- __BLOCK__ --><?php if($direction == 'asc'): ?>
                                    <i class="fa-solid fa-arrow-down-1-9 float-right mt-1"></i>
                                <?php else: ?>
                                    <i class="fa-solid fa-arrow-down-9-1 float-right mt-1"></i>
                                <?php endif; ?> <!-- __ENDBLOCK__ -->
                            <?php else: ?>
                                <i class="fa-solid fa-sort float-right mt-1"></i>
                            <?php endif; ?> <!-- __ENDBLOCK__ --></th>
                            <th>Estado</th>
                            <th style="cursor: pointer;" wire:click="order('created_at')">Fecha de Creacion
                            <!-- Sort -->
                            <!-- __BLOCK__ --><?php if($sort == 'created_at'): ?>
                                <!-- __BLOCK__ --><?php if($direction == 'asc'): ?>
                                    <i class="fa-solid fa-arrow-down-1-9 float-right mt-1"></i>
                                <?php else: ?>
                                    <i class="fa-solid fa-arrow-down-9-1 float-right mt-1"></i>
                                <?php endif; ?> <!-- __ENDBLOCK__ -->
                            <?php else: ?>
                                <i class="fa-solid fa-sort float-right mt-1"></i>
                            <?php endif; ?> <!-- __ENDBLOCK__ --></th>
                            <th>Opciones</th>
                        </tr>
                    </thead>
                    <tbody class="text-center">
                        <!-- __BLOCK__ --><?php $__currentLoopData = $solicitudes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $solicitud): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($solicitud->id); ?></td>
                            <td><?php echo e($solicitud->cliente); ?></td>
                            <td>S/. <?php echo e($solicitud->mon_sol); ?></td>
                            <td>
                                <!-- __BLOCK__ --><?php if($solicitud->estado == 'Aprobado'): ?>
                                    <span class="badge badge-success">Aprobado</span>
                                <?php elseif($solicitud->estado == 'En Analisis'): ?>
                                    <span class="badge badge-info">En Analisis</span>
                                <?php elseif($solicitud->estado == 'En Espera'): ?>
                                    <span class="badge badge-warning">En Espera</span>
                                <?php else: ?>
                                    <span class="badge badge-danger">Finalizado</span>
                                <?php endif; ?> <!-- __ENDBLOCK__ -->
                                    
                            </td>
                            <td><?php echo e($solicitud->fech_ate); ?></td>
                            <td>
                                <div class="btn-group">
                                    <button class="btn btn-secondary btn-sm dropdown-toggle" type="button" data-toggle="dropdown" aria-expanded="false">
                                        Acciones
                                    </button>
                                    <div class="dropdown-menu">
                                        <a href="<?php echo e(route('admin.solicitudes.edit', ['solicitude' => $solicitud->id ])); ?>" class="dropdown-item"><i class="far fa-pen-to-square mr-1"></i>Editar</a>
                                        <a href="<?php echo e(route('admin.solicitudes.show', ['solicitude' => $solicitud->id ])); ?>" class="dropdown-item"><i class="fas fa-file-pdf mr-1"></i>Ver Cronograma</a>
                                        <a href="#" class="dropdown-item"><i class="fas fa-trash mr-1"></i>Eliminar</a>
                                        <a href="#" class="dropdown-item"><i class="fas fa-money-bills mr-1"></i>Fondo Provicional</a>
                                    </div>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!-- __ENDBLOCK__ -->
                        <!-- -------------------------------------------------------------------------------------------------------- -->
                        <!-- -------------------------------------------------------------------------------------------------------- -->
                    </tbody>
                </table>
            <?php else: ?>
                <div class="text-center">
                    <p class="font-weight-bold text-muted">No hemos encontrado algun registro coincidente</p>
                </div>
            <?php endif; ?> <!-- __ENDBLOCK__ -->
            
        </div>
    </div>  
</div>
<?php /**PATH C:\xampp\htdocs\Santiago-System\resources\views/livewire/solicitudes/show-solicitudes.blade.php ENDPATH**/ ?>