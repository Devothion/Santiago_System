<div>
    <div class="card">
        <div class="card-header">
            <div class="d-flex w-full justify-content-around">
                <div class="row " style="margin-top: 20px;margin-bottom: 20px;margin-left: 10px;">

                    <div class="btn-group btn-group-toggle" data-toggle="buttons">
                        <label class="btn btn-outline-success m-2">
                            <input type="radio" name="options" id="option1" wire:click="updateSearch('Aprobado')" wire:loading.attr="disabled"> Aprobado <p><?php echo e($cant_aprobado); ?></p>
                        </label>                          
                        <label class="btn btn-outline-info m-2">
                          <input type="radio" name="options" id="option2" wire:click="updateSearch('En Analisis')"> En Analisis <p><?php echo e($cant_analisis); ?></p>
                        </label>
                        <label class="btn btn-outline-warning m-2">
                          <input type="radio" name="options" id="option3" wire:click="updateSearch('En Espera')"> En Espera <p><?php echo e($cant_espera); ?></p>
                        </label>
                        <label class="btn btn-outline-danger m-2">
                            <input type="radio" name="options" id="option4" wire:click="updateSearch('Finalizado')"> Finalizado <p><?php echo e($cant_finalizado); ?></p>
                        </label>
                    </div>

                </div>
            </div>
            <div class="d-flex justify-content-center">
                <a href="<?php echo e(route('admin.solicitudes.create')); ?>" class="btn btn-block btn-danger w-25 m-2"><i class="fa-solid fa-hand-holding-dollar mr-1"></i>Nueva Solicitud</a>
                <button class="btn btn-block btn-success w-25 m-2" wire:click='export'><i class="fa fa-file-excel mr-1"></i>Descargar Patron</button>
            </div>
            <div class="d-flex">
                <input type="text" wire:model.live="search" class="form-control" placeholder="Buscar por DNI, Apellidos o Estado">
            </div>
        </div>
        <div class="card-body">

            <!--[if BLOCK]><![endif]--><?php if($solicitudes->count()): ?>
                <table id="" class="table table-bordered table-striped">
                    <thead class="text-center">
                        <tr>
                            <th style="cursor: pointer;" wire:click="order('id')">ID 
                            <!-- Sort -->
                            <!--[if BLOCK]><![endif]--><?php if($sort == 'id'): ?>
                                <!--[if BLOCK]><![endif]--><?php if($direction == 'asc'): ?>
                                    <i class="fa-solid fa-arrow-down-1-9 float-right mt-1"></i>
                                <?php else: ?>
                                    <i class="fa-solid fa-arrow-down-9-1 float-right mt-1"></i>
                                <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
                            <?php else: ?>
                                <i class="fa-solid fa-sort float-right mt-1"></i>
                            <?php endif; ?> <!--[if ENDBLOCK]><![endif]--></th>
                            <th style="cursor: pointer;" wire:click="order('nombre_cliente')">Nombres
                            <!-- Sort -->
                            <!--[if BLOCK]><![endif]--><?php if($sort == 'nombre_cliente'): ?>
                                <!--[if BLOCK]><![endif]--><?php if($direction == 'asc'): ?>
                                    <i class="fa-solid fa-arrow-down-a-z float-right mt-1"></i>
                                <?php else: ?>
                                    <i class="fa-solid fa-arrow-down-z-a float-right mt-1"></i>
                                <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
                            <?php else: ?>
                                <i class="fa-solid fa-sort float-right mt-1"></i>
                            <?php endif; ?> <!--[if ENDBLOCK]><![endif]--></th>
                            <th style="cursor: pointer;" wire:click="order('')">DNI
                            <!-- Sort -->
                            <!--[if BLOCK]><![endif]--><?php if($sort == ''): ?>
                                <!--[if BLOCK]><![endif]--><?php if($direction == 'asc'): ?>
                                    <i class="fa-solid fa-arrow-down-1-9 float-right mt-1"></i>
                                <?php else: ?>
                                    <i class="fa-solid fa-arrow-down-9-1 float-right mt-1"></i>
                                <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
                            <?php else: ?>
                                <i class="fa-solid fa-sort float-right mt-1"></i>
                            <?php endif; ?> <!--[if ENDBLOCK]><![endif]--></th>
                            <th style="cursor: pointer;" wire:click="order('mon_sol')">Monto
                            <!-- Sort -->
                            <!--[if BLOCK]><![endif]--><?php if($sort == 'mon_sol'): ?>
                                <!--[if BLOCK]><![endif]--><?php if($direction == 'asc'): ?>
                                    <i class="fa-solid fa-arrow-down-1-9 float-right mt-1"></i>
                                <?php else: ?>
                                    <i class="fa-solid fa-arrow-down-9-1 float-right mt-1"></i>
                                <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
                            <?php else: ?>
                                <i class="fa-solid fa-sort float-right mt-1"></i>
                            <?php endif; ?> <!--[if ENDBLOCK]><![endif]--></th>
                            <th>Estado</th>
                            <th style="cursor: pointer;" wire:click="order('created_at')">Fecha de Creacion
                            <!-- Sort -->
                            <!--[if BLOCK]><![endif]--><?php if($sort == 'created_at'): ?>
                                <!--[if BLOCK]><![endif]--><?php if($direction == 'asc'): ?>
                                    <i class="fa-solid fa-arrow-down-1-9 float-right mt-1"></i>
                                <?php else: ?>
                                    <i class="fa-solid fa-arrow-down-9-1 float-right mt-1"></i>
                                <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
                            <?php else: ?>
                                <i class="fa-solid fa-sort float-right mt-1"></i>
                            <?php endif; ?> <!--[if ENDBLOCK]><![endif]--></th>
                            <th>Opciones</th>
                        </tr>
                    </thead>
                    <tbody class="text-center">
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $solicitudes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $solicitud): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($solicitud->id); ?></td>
                            <td><?php echo e($solicitud->nombre_cliente); ?></td>
                            <td><?php echo e($solicitud->cliente->documento); ?></td>
                            <td>S/. <?php echo e($solicitud->mon_sol); ?></td>
                            <td>
                                <!--[if BLOCK]><![endif]--><?php if($solicitud->estado == 'Aprobado'): ?>
                                    <span class="badge badge-success">Aprobado</span>
                                <?php elseif($solicitud->estado == 'En Analisis'): ?>
                                    <span class="badge badge-info">En Analisis</span>
                                <?php elseif($solicitud->estado == 'En Espera'): ?>
                                    <span class="badge badge-warning">En Espera</span>
                                <?php else: ?>
                                    <span class="badge badge-danger">Finalizado</span>
                                <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
                                    
                            </td>
                            <td><?php echo e($solicitud->fech_ate); ?></td>
                            <td>
                                <div class="btn-group">
                                    <button class="btn btn-secondary btn-sm dropdown-toggle" type="button" data-toggle="dropdown" aria-expanded="false">
                                        Acciones
                                    </button>
                                    <div class="dropdown-menu">
                                        <a href="<?php echo e(route('admin.solicitudes.edit', ['solicitude' => $solicitud->id ])); ?>" class="dropdown-item"><i class="far fa-pen-to-square mr-1"></i>Editar</a>
                                        <a href="<?php echo e(route('admin.solicitudes.show', ['solicitude' => $solicitud->id ])); ?>" class="dropdown-item"><i class="fas fa-file-pdf mr-1"></i>Ver Cronograma</a>
                                        <a href="#" class="dropdown-item"><i class="fas fa-trash mr-1"></i>Eliminar</a>
                                        <a href="<?php echo e(route('admin.fondosprovicionales.edit', ['fondo_provicional' => $solicitud->id])); ?>" class="dropdown-item"><i class="fas fa-money-bills mr-1"></i>Fondo Provicional</a>
                                    </div>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
                    </tbody>
                </table>
                <div class="float-right mt-3">
                    <?php echo e($solicitudes->links()); ?>

                </div>
            <?php else: ?>
                <div class="text-center">
                    <p class="font-weight-bold text-muted">No hemos encontrado algun registro coincidente</p>
                </div>
            <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
            
        </div>

        <script>

            // Obtén todos los botones
            var buttons = document.querySelectorAll('.btn-group-toggle .btn');

            // Añade un controlador de eventos a cada botón
            buttons.forEach(function(button) {
                button.addEventListener('click', function() {
                    // Elimina la clase 'btn-transparent' y añade la clase 'btn-secondary' al botón clicado
                    this.classList.remove('btn-transparent');
                    this.classList.add('btn-secondary');

                    // Para los demás botones, elimina la clase 'btn-secondary' y añade la clase 'btn-transparent'
                    buttons.forEach(function(otherButton) {
                        if (otherButton !== this) {
                            otherButton.classList.remove('btn-secondary');
                            otherButton.classList.add('btn-transparent');
                        }
                    }, this);
                });
            });

        </script>

    </div>  
</div>
<?php /**PATH C:\xampp\htdocs\Santiago-System\resources\views/livewire/solicitudes/show-solicitudes.blade.php ENDPATH**/ ?>