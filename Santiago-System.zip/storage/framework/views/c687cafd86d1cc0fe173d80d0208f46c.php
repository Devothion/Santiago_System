<div>
    <div class="card">
        <div class="card-header">
            
            <div class="d-flex">
                <a href="<?php echo e(route('admin.clientes.create')); ?>" class="btn btn-block btn-danger w-25 m-2"><i class="fa-solid fa-user-plus mr-1"></i>Nuevo Cliente</a>
                <button class="btn btn-block btn-success w-25 m-2" wire:click='export'><i class="fa fa-file-excel mr-1"></i>Descargar Patron</button>
                <button class="btn btn-block btn-primary w-25 m-2" wire:click='export1'><i class="fa-solid fa-circle-plus mr-1"></i>Asignar otros conceptos</button>
                <a href="#" class="btn btn-block btn-dark w-25 m-2"><i class="fa-solid fa-file-pen mr-1"></i>Actualizar Status</a>
            </div>
            <div class="d-flex">
                <input type="text" wire:model.live="search" class="form-control" placeholder="Buscar por DNI, Apellidos o Estado">
            </div>
        </div>
        <div class="card-body">

            <!-- __BLOCK__ --><?php if($clientes->count()): ?>
                <table id="" class="table table-bordered table-striped">
                    <thead class="text-center">
                        <tr>
                            <th style="cursor: pointer;" wire:click="order('id')">ID
                            <!-- Sort -->
                            <!-- __BLOCK__ --><?php if($sort == 'id'): ?>
                                <!-- __BLOCK__ --><?php if($direction == 'asc'): ?>
                                    <i class="fa-solid fa-arrow-down-1-9 float-right mt-1"></i>
                                <?php else: ?>
                                    <i class="fa-solid fa-arrow-down-9-1 float-right mt-1"></i>
                                <?php endif; ?> <!-- __ENDBLOCK__ -->
                            <?php else: ?>
                                <i class="fa-solid fa-sort float-right mt-1"></i>
                            <?php endif; ?> <!-- __ENDBLOCK__ --></th>
                            <th style="cursor: pointer;" wire:click="order('nombres')">Nombres
                            <!-- Sort -->
                            <!-- __BLOCK__ --><?php if($sort == 'nombres'): ?>
                                <!-- __BLOCK__ --><?php if($direction == 'asc'): ?>
                                    <i class="fa-solid fa-arrow-down-a-z float-right mt-1"></i>
                                <?php else: ?>
                                    <i class="fa-solid fa-arrow-down-z-a float-right mt-1"></i>
                                <?php endif; ?> <!-- __ENDBLOCK__ -->
                            <?php else: ?>
                                <i class="fa-solid fa-sort float-right mt-1"></i>
                            <?php endif; ?> <!-- __ENDBLOCK__ --></th>
                            <th style="cursor: pointer;" wire:click="order('documento')">DNI
                            <!-- Sort -->
                            <!-- __BLOCK__ --><?php if($sort == 'documento'): ?>
                                <!-- __BLOCK__ --><?php if($direction == 'asc'): ?>
                                    <i class="fa-solid fa-arrow-down-1-9 float-right mt-1"></i>
                                <?php else: ?>
                                    <i class="fa-solid fa-arrow-down-9-1 float-right mt-1"></i>
                                <?php endif; ?> <!-- __ENDBLOCK__ -->
                            <?php else: ?>
                                <i class="fa-solid fa-sort float-right mt-1"></i>
                            <?php endif; ?> <!-- __ENDBLOCK__ --></th>
                            <th style="cursor: pointer;" wire:click="order('created_at')">Fecha de Creacion
                            <!-- Sort -->
                            <!-- __BLOCK__ --><?php if($sort == 'created_at'): ?>
                                <!-- __BLOCK__ --><?php if($direction == 'asc'): ?>
                                    <i class="fa-solid fa-arrow-down-1-9 float-right mt-1"></i>
                                <?php else: ?>
                                    <i class="fa-solid fa-arrow-down-9-1 float-right mt-1"></i>
                                <?php endif; ?> <!-- __ENDBLOCK__ -->
                            <?php else: ?>
                                <i class="fa-solid fa-sort float-right mt-1"></i>
                            <?php endif; ?> <!-- __ENDBLOCK__ --></th>
                            <th>Opciones</th>
                        </tr>
                    </thead>
                    <tbody class="text-center">
                        <!-- __BLOCK__ --><?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($cliente->id); ?></td>
                            <td><?php echo e($cliente->nombres); ?></td>
                            <td><?php echo e($cliente->documento); ?></td>
                            <td><?php echo e($cliente->created_at); ?></td>
                            <td>
                                <a href="<?php echo e(route('admin.clientes.edit', ['cliente' => $cliente->id ])); ?>" class="btn btn-success btn-sm"><i class="fa-solid fa-user-pen mr-1"></i>Editar</a>
                                <button type="button" class="btn btn-warning btn-sm"><i class="fa-solid fa-money-bill-wave mr-1"></i>Ver Creditos</button>
                                <button type="button" class="btn btn-info btn-sm"><i class="fa-solid fa-file-invoice-dollar mr-1"></i>Nueva Solicitud</button>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!-- __ENDBLOCK__ -->
                    </tbody>

                </table>
            <?php else: ?>
                <div class="text-center">
                    <p class="font-weight-bold text-muted">No hemos encontrado algun registro coincidente</p>
                </div>
            <?php endif; ?> <!-- __ENDBLOCK__ -->
            
        </div>
    </div>  
</div>
<?php /**PATH C:\xampp\htdocs\Santiago-System\resources\views/livewire/clientes/show-clientes.blade.php ENDPATH**/ ?>