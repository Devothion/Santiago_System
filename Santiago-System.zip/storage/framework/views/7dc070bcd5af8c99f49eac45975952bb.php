

<?php $__env->startSection('title', 'Solicitudes'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1 class="m-0 text-dark">Solicitudes</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if(session('info')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(session('info')); ?>

        </div>
    <?php endif; ?>
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('solicitudes.show-solicitudes');

$__html = app('livewire')->mount($__name, $__params, 'Pp5Iuid', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <!-- <link rel="stylesheet" href="/css/admin_custom.css"> -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script> console.log('Hi!'); </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Santiago-System\resources\views/admin/Solicitudes/index.blade.php ENDPATH**/ ?>