

<?php $__env->startSection('title', 'Perfil'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1 class="m-0 text-dark">Perfil</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="card">
        <div class="card-body">
            <div class="row">
                <div class="col-6">
                    <div class="form-group">
                        <label for="nombres">Nombres</label>
                        <input type="text" class="form-control" name="nombres" id="nombres">
                    </div>
                </div>
                <div class="col-6">
                    <div class="form-group">
                        <label for="no">Email</label>
                        <input type="email" class="form-control" name="email" id="email">
                    </div>
                </div>
            </div>
        </div>
    </div>    
    

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <!-- <link rel="stylesheet" href="/css/admin_custom.css"> -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script> console.log('Hi!'); </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Santiago-System\resources\views/admin/Perfil/index.blade.php ENDPATH**/ ?>