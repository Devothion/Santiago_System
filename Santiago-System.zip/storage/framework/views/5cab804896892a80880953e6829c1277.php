<div>
    <div class="card">
        <div class="card-header">
            <div class="d-flex">
                <a href="<?php echo e(route('admin.clientes.create')); ?>" class="btn btn-block btn-danger w-25 m-2"><i class="fa-solid fa-user-plus mr-1"></i>Nuevo Cliente</a>
                <button class="btn btn-block btn-success w-25 m-2" wire:click='export'><i class="fa fa-file-excel mr-1"></i>Descargar Patron</button>
                <button class="btn btn-block btn-primary w-25 m-2" wire:click='export1'><i class="fa-solid fa-circle-plus mr-1"></i>Asignar otros conceptos</button>
                <a href="#" class="btn btn-block btn-dark w-25 m-2"><i class="fa-solid fa-file-pen mr-1"></i>Actualizar Status</a>
            </div>
            <div class="d-flex">
                <input type="text" wire:model.live="search" class="form-control" placeholder="Buscar por DNI, Apellidos o Estado">
            </div>
        </div>
        <div class="card-body">

            <!-- __BLOCK__ --><?php if($gestiones->count()): ?>
                <table id="" class="table table-bordered table-striped">
                    <thead class="text-center">
                        <tr>
                            <th style="cursor: pointer;" wire:click="order('id')">ID
                            <!-- Sort -->
                            <!-- __BLOCK__ --><?php if($sort == 'id'): ?>
                                <!-- __BLOCK__ --><?php if($direction == 'asc'): ?>
                                    <i class="fa-solid fa-arrow-down-1-9 float-right mt-1"></i>
                                <?php else: ?>
                                    <i class="fa-solid fa-arrow-down-9-1 float-right mt-1"></i>
                                <?php endif; ?> <!-- __ENDBLOCK__ -->
                            <?php else: ?>
                                <i class="fa-solid fa-sort float-right mt-1"></i>
                            <?php endif; ?> <!-- __ENDBLOCK__ --></th>
                            <th style="cursor: pointer;" wire:click="order('cliente')">Cliente
                            <!-- Sort -->
                            <!-- __BLOCK__ --><?php if($sort == 'cliente'): ?>
                                <!-- __BLOCK__ --><?php if($direction == 'asc'): ?>
                                    <i class="fa-solid fa-arrow-down-a-z float-right mt-1"></i>
                                <?php else: ?>
                                    <i class="fa-solid fa-arrow-down-z-a float-right mt-1"></i>
                                <?php endif; ?> <!-- __ENDBLOCK__ -->
                            <?php else: ?>
                                <i class="fa-solid fa-sort float-right mt-1"></i>
                            <?php endif; ?> <!-- __ENDBLOCK__ --></th>
                            <th style="cursor: pointer;" wire:click="order('fecha_operacion')">Fecha
                            <!-- Sort -->
                            <!-- __BLOCK__ --><?php if($sort == 'fecha_operacion'): ?>
                                <!-- __BLOCK__ --><?php if($direction == 'asc'): ?>
                                    <i class="fa-solid fa-arrow-down-1-9 float-right mt-1"></i>
                                <?php else: ?>
                                    <i class="fa-solid fa-arrow-down-9-1 float-right mt-1"></i>
                                <?php endif; ?> <!-- __ENDBLOCK__ -->
                            <?php else: ?>
                                <i class="fa-solid fa-sort float-right mt-1"></i>
                            <?php endif; ?> <!-- __ENDBLOCK__ --></th>
                            <th style="cursor: pointer;" wire:click="order('estado')">Estado
                            <!-- Sort -->
                            <!-- __BLOCK__ --><?php if($sort == 'estado'): ?>
                                <!-- __BLOCK__ --><?php if($direction == 'asc'): ?>
                                    <i class="fa-solid fa-arrow-down-1-9 float-right mt-1"></i>
                                <?php else: ?>
                                    <i class="fa-solid fa-arrow-down-9-1 float-right mt-1"></i>
                                <?php endif; ?> <!-- __ENDBLOCK__ -->
                            <?php else: ?>
                                <i class="fa-solid fa-sort float-right mt-1"></i>
                            <?php endif; ?> <!-- __ENDBLOCK__ --></th>
                            <th>Observacion</th>
                        </tr>
                    </thead>
                    <tbody class="text-center">
                        <!-- __BLOCK__ --><?php $__currentLoopData = $gestiones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gestion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($gestion->id); ?></td>
                            <td><?php echo e($gestion->cliente); ?></td>
                            <td><?php echo e($gestion->fecha_operacion); ?></td>
                            <td><?php echo e($gestion->estado); ?></td>
                            <td>
                                <!-- __BLOCK__ --><?php if(empty($gestion->observaciones)): ?>
                                    <?php echo e('Sin detalles que mostrar'); ?>

                                <?php else: ?>
                                    <?php echo e($gestion->observaciones); ?>

                                <?php endif; ?> <!-- __ENDBLOCK__ -->                                
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!-- __ENDBLOCK__ -->
                    </tbody>
                </table>
                <div class="float-right mt-3">
                    <?php echo e($gestiones->links()); ?>

                </div>
            <?php else: ?>
                <div class="text-center">
                    <p class="font-weight-bold text-muted">No hemos encontrado algun registro coincidente</p>
                </div>
            <?php endif; ?> <!-- __ENDBLOCK__ -->
            
        </div>
    </div>  
</div>
<?php /**PATH C:\xampp\htdocs\Santiago-System\resources\views/livewire/gestiones/show-gestiones.blade.php ENDPATH**/ ?>