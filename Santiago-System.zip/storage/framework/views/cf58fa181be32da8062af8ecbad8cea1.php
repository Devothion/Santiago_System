

<?php $__env->startSection('title', 'Nueva Solicitud'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1 class="m-0 text-dark">Crear Solicitud</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <!-- ------------------------------------- -->
    <!-- FALTAN ARREGLAR LOS ID's Y LOS NAME's -->
    <!-- FALTAN ARREGLAR LA ETIQUETA FORM ------->
    <!-- ------------------------------------- -->
    <form action="<?php echo e(route('admin.solicitudes.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="card">
            <div class="card-body">
                <div class="alert alert-info alert-dismissible fade show absolute-right" role="alert">
                    <strong>Recuerda:</strong> Si el cliente no existe, lo puedes crear dando click en "Agregar".
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="row">
                    <div class="col-12">
                        <div class="form-group">
                            <label for="estado">Estado</label>
                            <select class="form-control" id="estado" name="estado">
                                <option value="" selected>Selecciona</option>
                                <option>En Analisis</option>
                                <option>En Espera</option>
                                <option>Finalizado</option>
                                <option>Aprobado</option>
                            </select>  
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="form-group">
                            <label for="cliente">Cliente</label>
                            <div class="input-group mb-3">
                                <select class="custom-select" id="cliente" name="cliente" data-live-search="true">
                                    <option selected>Selecciona</option>
                                    <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($cliente->id); ?>"><?php echo e($cliente->nombres.' '.$cliente->ape_pat.' '.$cliente->ape_mat); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <div class="input-group-append">
                                    <a href="<?php echo e(route('admin.clientes.create')); ?>" class="btn btn-outline-info">Agregar</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-3">
                        <div class="form-group">
                            <label for="tSolicitud">Tipo Solicitud</label>
                            <select class="form-control" id="tSolicitud" name="tSolicitud">
                                <option value="" selected>Selecciona</option>
                                <option>Nueva</option>
                                <option>Antigua</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-3">
                        <div class="form-group">
                            <label for="cuentaAsignada">Cuenta Asignada</label>
                            <select class="form-control" id="cuentaAsignada" name="cuentaAsignada">
                                <option value="" selected>Selecciona</option>
                                <option>BCP-5</option>
                                <option>BBVA-5</option>
                                <option>Scotiabank-1</option>
                                <option>BCP-1</option>
                                <option>BCP-2</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-3">
                        <div class="form-group">
                            <label for="fechaAtencion">Fecha de atencion</label>
                            <input type="date" class="form-control" name="fechaAtencion" id="fechaAtencion">
                        </div>
                    </div>
                    <div class="col-3">
                        <div class="form-group">
                            <label for="plazo">Plazo</label>
                            <select class="form-control" id="plazo" name="plazo">
                                <option value="" selected>Selecciona</option>
                                <option value="12">12 semanas</option>
                                <option value="15">15 semanas</option>
                                <option value="18">18 semanas</option>
                                <option value="20">20 semanas</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-3">
                        <div class="form-group">
                            <label for="montoSolicitado">Monto Solicitado</label>
                            <input type="number" class="form-control" name="montoSolicitado" id="montoSolicitado" placeholder="0.00">
                        </div>
                    </div>
                    <div class="col-3">
                        <div class="form-group">
                            <label for="tasaInteres">Tasa de interes</label>
                            <input type="number" class="form-control" name="tasaInteres" id="tasaInteres" placeholder="0.00">
                        </div>
                    </div>
                    <div class="col-3">
                        <div class="form-group">
                            <label for="capitalInteres">Capital + Interes</label>
                            <input type="number" class="form-control" name="capitaInteres" id="capitaInteres" placeholder="0.00">
                        </div>
                    </div>
                    <div class="col-3">
                        <div class="form-group">
                            <label for="tasaMora">Tasa de Mora</label>
                            <input type="number" class="form-control" name="tasaMora" id="tasaMora" value="5.00">
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="form-group">
                            <label for="frecuenciaPago">Frecuencia de Pago</label>
                            <select class="form-control" id="frecuenciaPago" name="frecuenciaPago">
                                <option value="" selected>Selecciona</option>
                                <option>Semanal</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="form-group">
                            <label for="fechaPrimerPago">Fecha de Primer pago</label>
                            <input type="date" class="form-control" name="fechaPrimerPago" id="fechaPrimerPago">
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="form-group">
                            <label for="asesorCredito">Asesor de credito</label>
                            <select class="form-control" id="asesorCredito" name="asesorCredito">
                                <option value="1" selected>Selecciona</option>
                                <?php $__currentLoopData = $asesores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asesor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($asesor->id); ?>"><?php echo e($asesor->codigo.' '.$asesor->nombres); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="form-group">
                            <label for="observaciones">Observaciones</label>
                            <textarea class="form-control" id="observaciones" name="observaciones" rows="3"></textarea>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="d-flex justify-content-between mb-4">
                            <a href="<?php echo e(route('admin.solicitudes.index')); ?>" class="btn btn-lg btn-dark mr-4"><i class="fa-solid fa-right-from-bracket mr-1"></i>Cancelar</a>
                            <button type="submit" class="btn btn-lg btn-success"><i class="fa-solid fa-floppy-disk mr-1"></i>Guardar</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        $(document).ready(function(){

            $(".alert").delay(4500).slideUp(200, function() {
                $(this).alert('close');
            });

            $('#plazo').change(function(){
                var plazo = $(this).val();
                var tasaInteres;
                switch(plazo) {
                case '12':
                    tasaInteres = 104;
                    tasaCliente = 44/100;
                    break;
                case '15':
                    tasaInteres = 130;
                    tasaCliente = 50/100;
                    break;
                case '18':
                    tasaInteres = 156;
                    tasaCliente = 50/100;
                    break;
                case '20':
                    tasaInteres = 173;
                    tasaCliente = 50/100;
                    break;
                default:
                    tasaInteres = '';
                    tasaCliente = '';
                }
                $('#tasaInteres').val(tasaInteres);
            });
            $('#montoSolicitado').on('input', function() {
                $('#capitaInteres').val(this.value * (1 + tasaCliente));
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Santiago-System\resources\views/admin/Solicitudes/create.blade.php ENDPATH**/ ?>