<div class="row">
    <div class="col-12">
        <div class="form-group">
            <label for="plazo">Plazo</label>
            <select class="form-control" id="plazo" name="plazo">
                <option value="" selected>Selecciona</option>
                <option>12 semanas</option>
                <option>15 semanas</option>
                <option>18 semanas</option>
                <option>20 semanas</option>
            </select>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\Santiago-System\resources\views/livewire/solicitudes/calcular/interes.blade.php ENDPATH**/ ?>