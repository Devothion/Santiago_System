<div>
    <div>
        <div class="card">
            <div class="card-header">
                
                <div class="d-flex">
                    <a href="<?php echo e(route('admin.cuentas.create')); ?>" class="btn btn-block btn-danger w-25 m-2"><i class="fa-solid fa-square-plus mr-1"></i>Nueva Cuenta</a>
                    <button class="btn btn-block btn-success w-25 m-2" wire:click='export'><i class="fa fa-file-excel mr-1"></i>Descargar Patron</button>
                    <button class="btn btn-block btn-primary w-25 m-2" wire:click='export1'><i class="fa-solid fa-circle-plus mr-1"></i>Asignar otros conceptos</button>
                    <a href="#" class="btn btn-block btn-dark w-25 m-2"><i class="fa-solid fa-file-pen mr-1"></i>Actualizar Status</a>
                </div>
                <div class="d-flex">
                    <input type="text" wire:keydown="reset_page" wire:model="search-prestamo" class="form-control" placeholder="Buscar por DNI, Apellidos o Estado">
                </div>
            </div>
            <div class="card-body">
                <table id="" class="table table-bordered table-striped">
                    <thead class="text-center">
                        <tr>
                            <th>Entidad Bancaria</th>
                            <th>Numero de Cuenta</th>
                            <th>Codigo</th>
                            <th>Opciones</th>
                        </tr>
                    </thead>
                    <tbody class="text-center">
                        <!-- __BLOCK__ --><?php $__currentLoopData = $cuentas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cuenta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($cuenta->entidadBancaria->banco); ?></td>
                            <td><?php echo e($cuenta->numero_cuenta); ?></td>
                            <td><?php echo e($cuenta->codigo); ?></td>
                            <td>
                                <div class="btn-group">
                                    <button class="btn btn-secondary btn-sm dropdown-toggle" type="button" data-toggle="dropdown" aria-expanded="false">
                                        Acciones
                                    </button>
                                    <div class="dropdown-menu">
                                        <!-- PODRIAMOS PONER DISTINTOS COLORES DE TEXTO A LAS OPCIONES PARA UN ESTILO (TEXT-DANGER) -->
                                        <a href="<?php echo e(route('admin.cuentas.edit', [$cuenta->id])); ?>" class="dropdown-item"><i class="fas fa-pen-to-square mr-1"></i>Editar Cuenta</a>
                                        <a href="#" class="dropdown-item"><i class="fas fa-trash mr-1"></i>Eliminar Cuenta</a>
                                    </div>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!-- __ENDBLOCK__ -->
                    </tbody>
                </table>
            </div>
        </div>  
    </div>
    
    
</div>
<?php /**PATH C:\xampp\htdocs\Santiago-System\resources\views/livewire/cuentas/show-cuentas.blade.php ENDPATH**/ ?>