<?php

namespace App\Livewire\Clientes\Zona;

use Livewire\Component;

class CreateZona extends Component
{
    public function render()
    {
        return view('livewire.clientes.zona.create-zona');
    }
}
