<div class="col-4">
    <div class="form-group">
        <label for="abono">Abono</label>
        <input type="number" class="form-control" name="abono" id="abono" value="{{$subtotal}}" readonly>
    </div>
</div>
